function App() {
  return (
    <p>Hello</p>
  );
}

export default App;