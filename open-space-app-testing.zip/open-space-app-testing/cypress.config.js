// eslint-disable-next-line import/no-extraneous-dependencies
import cypress from 'cypress';

export default cypress.defineConfig({
  e2e: {
    video: false,
  },
});
