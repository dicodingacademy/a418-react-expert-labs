import React from 'react';
import Stopwatch from './components/Stopwatch';

import './styles/style.css';

function App() {
  return (
    <Stopwatch />
  );
}

export default App;
