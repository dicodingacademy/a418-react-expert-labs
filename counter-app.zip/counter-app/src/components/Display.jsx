function Display({ count }) {
  return (
    <div className="Display">
      <h1>{count}</h1>
    </div>
  )
}

export default Display;