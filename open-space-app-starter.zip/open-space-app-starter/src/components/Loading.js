import React from 'react';

function Loading() {
  return (
    <div className="loading">
      {/* @TODO: use react-redux-loading-bar to show loading bar */}
    </div>
  );
}

export default Loading;
