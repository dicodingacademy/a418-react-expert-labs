/**
 * @TODO: Define the reducer for the authUser state
 */
