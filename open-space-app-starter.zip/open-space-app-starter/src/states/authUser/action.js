/**
 * @TODO: Define all the actions (creator) for the authUser state
 */
