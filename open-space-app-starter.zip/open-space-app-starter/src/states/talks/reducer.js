/**
 * @TODO: Define the reducer for the talks state
 */
