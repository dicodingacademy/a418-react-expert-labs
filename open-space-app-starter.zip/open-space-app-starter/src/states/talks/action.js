/**
 * @TODO: Define all the actions (creator) for the talks state
 */
