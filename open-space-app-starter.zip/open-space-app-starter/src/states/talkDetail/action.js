/**
 * @TODO: Define all the actions (creator) for the talkDetail state
 */
