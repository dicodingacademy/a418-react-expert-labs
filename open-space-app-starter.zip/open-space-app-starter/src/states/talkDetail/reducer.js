/**
 * @TODO: Define reducer for the talkDetail state
 */
