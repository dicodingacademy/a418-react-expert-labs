/**
 * @TODO: Define reducer for the users state
 */
