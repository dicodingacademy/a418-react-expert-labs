/**
 * @TODO: Define all the actions (creator) for the users state
 */
