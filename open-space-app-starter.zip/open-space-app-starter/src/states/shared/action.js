/**
 * @TODO: Define all the actions (creator) that uses a combination of actions from various domain
 */
