/**
 * @TODO: Create Redux store
 */
