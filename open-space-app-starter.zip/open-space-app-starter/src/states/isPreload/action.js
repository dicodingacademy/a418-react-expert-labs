/**
 * @TODO: Define all the actions (creator) for the isPreLoad state
 */
