/**
 * @TODO: Define reducer for the isPreLoad state
 */
